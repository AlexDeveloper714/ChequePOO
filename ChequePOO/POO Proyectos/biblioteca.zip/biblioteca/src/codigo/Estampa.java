
package codigo;

import java.io.*;


public class Estampa extends CatalogoEstampa {

    public Estampa(String UserName,String nombreEstampa, String tipoEstampa, int precioEstampa, File estampa) {
        super(UserName,nombreEstampa, tipoEstampa, precioEstampa, estampa);
    }    
}
