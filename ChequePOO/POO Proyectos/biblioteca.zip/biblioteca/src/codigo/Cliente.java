package codigo;

public class Cliente extends Usuario {

    public Cliente(String nombre, String documento, String Usuario, String Contraseña, String email, String numeroCuenta) {
        super(nombre, documento, Usuario, Contraseña, email, numeroCuenta);
    }
    
   
   
   
}
