
package codigo;


public class Artista extends Usuario {

    public Artista(String nombre, String documento, String Usuario, String Contraseña, String email, String numeroCuenta) {
        super(nombre, documento, Usuario, Contraseña, email, numeroCuenta);
    }
    
    
}
