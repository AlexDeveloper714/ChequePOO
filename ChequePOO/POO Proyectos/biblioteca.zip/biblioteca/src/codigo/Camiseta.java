
package codigo;

import java.io.*;


public class Camiseta extends CatalogoCamiseta {

    public Camiseta(int idCamiseta, String talla, String tipoCamiseta, String color, File estampa,String Posicion, int Precio,String Usuario) {
        super(idCamiseta, talla, tipoCamiseta, color,estampa,Posicion,Precio,Usuario);
    }
    
    
}
