
package codigo;


public class Administrador extends Usuario {

    public Administrador(String nombre, String documento, String Usuario, String Contraseña, String email) {
        super(nombre, documento, Usuario, Contraseña, email);
    }
    
    
}
